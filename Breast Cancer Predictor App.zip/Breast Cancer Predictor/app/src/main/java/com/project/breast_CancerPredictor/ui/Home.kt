package com.project.breast_CancerPredictor.ui

import Project.breast_CancerPredictor.R
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.os.Bundle
import com.google.android.material.floatingactionbutton.FloatingActionButton


open class Home: AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_layout)


        val  buttonFirst = findViewById<FloatingActionButton>(R.id.button_first)
        val  buttonSecond = findViewById<FloatingActionButton>(R.id.button_second)

        buttonFirst.setOnClickListener {
            val intent = Intent(this@Home, Camera::class.java)
            startActivity(intent)
        }
        buttonSecond.setOnClickListener {
            val intent = Intent(this@Home, MainActivity::class.java)
            startActivity(intent)
        }


    }


}