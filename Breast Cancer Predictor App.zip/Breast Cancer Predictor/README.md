# ChatBot
This is a sample app that can be used to experiment with creating real chat apps in Android with Kotlin.

Clone the sample code and play around with the classes and the xml files to create your own ChatBot app!
