package com.project.breast_CancerPredictor.utils

object BotResponse {

    fun basicResponses(_message: String): String {

        return when (_message) {

            "Yes", "yes", "YES" -> {
                kotlin.run {  "Question 1:Do you Have Swelling of all or part of a breast (even if no lump is felt)?"}
            }
            "Yes1", "yes1", "YES1", "No1", "no1", "NO1" -> {
                kotlin.run { "Question 2:Do you Have Skin dimpling (sometimes looking like an orange peel) ?" }
            }
            "Yes2", "yes2", "YES2", "No2", "no2", "NO2" -> {
                kotlin.run { "Question 3:Do you feel Breast or nipple pain ?" }
            }
            "Yes3", "yes3", "YES3", "No3", "no3", "NO3" -> {
                kotlin.run {  "Question 4:Do you Have Nipple retraction (turning inward) ?" }
            }
            "Yes4", "yes4", "YES4", "No4", "no4", "NO$4" -> {
                kotlin.run {"Question 5:Do you Have Nipple or breast skin that is red, dry, flaking, or thickened ?"}
            }
            "Yes5", "yes5", "YES5", "No5", "no5", "NO5" -> {
                kotlin.run { "Question 6:Do you Have Nipple discharge (other than breast milk) ?" }
            }
            "Yes6", "yes6", "YES6", "No6", "no6", "NO6" -> {
                kotlin.run { "Question 7:Do you Have Swollen lymph nodes under the arm or near the collar bone (Sometimes this can be a sign of breast cancer spread even before the original tumor in the breast is large enough to be felt.) ?" }
            }
            "Yes7", "yes7", "YES7", "No7", "no7", "NO7" -> {
                kotlin.run { "Question 8:Do you feel a new lump or mass(painless,hard ) on your breast ?" }
            }
            "Yes8", "yes8", "YES8", "No8", "no8", "NO8" -> {
                kotlin.run { "Question 9:Do you Have Redness or flaky skin in the nipple area or the breast ?" }
            }
            "Yes9", "yes9", "YES9", "No9", "no9", "NO9" -> {
                kotlin.run { "Question 10:Do you feel Pain in any area of the breast ?" }
            }
            "Yes10", "yes10", "YES10", "No10", "no10", "NO10" -> {
                kotlin.run { "Thank you for your answers your result will be shown soon!!\n\n PRESS ANY KEY" }
            }

            else -> {
                run{"you can only answer Yes(n)or No(n) with their respect question number"}
            }
        }
    }
}









