package com.project.breast_CancerPredictor.utils

object Constants {
    const val SEND_ID = "SEND_ID"
    const val RECEIVE_ID = "RECEIVE_ID"
}