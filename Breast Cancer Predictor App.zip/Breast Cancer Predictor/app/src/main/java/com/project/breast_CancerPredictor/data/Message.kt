package com.project.breast_CancerPredictor.data

data class Message(val message: String, val id: String)

